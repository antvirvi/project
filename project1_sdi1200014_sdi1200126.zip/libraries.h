#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

int buffer_size = 16;
int word_size = 8;
int table_size = 4;

